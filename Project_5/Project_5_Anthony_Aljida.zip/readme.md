# How to run the program

1. In the root directory run

```bash
    make
```

2. Then run

```bash
    ./main
```

## Sample outputs

Rochester, Michigan - 00:00:00

New York - 13:35:02

New York - 13:35:02

Rochester, Michigan - 00:00:00

New York - 13:35:02

New York - 13:35:02

Rochester, Michigan - 01:00:00

(Top and bottom are separate objects)

Rochester, Michigan - 00:00:01

New York - 13:35:02 PM
