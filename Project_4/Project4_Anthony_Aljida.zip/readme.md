# How to compile and run the program

1. In the root directory run

```bash
    make
```

2. Then run

```bash
    ./main
```

## Sample outputs

Time: 12:00:00 AM (12-hour format)

Time: 03:59:50 PM (12-hour format)

Time: 12:00:01 AM (12-hour format)

Time: 03:59:51 PM (12-hour format)

Time: 00:00:02 (24-hour format)

Time: 15:59:52 (24-hour format)
